import sn_preprocessing as pre
import os
import matplotlib.pyplot as plt
import pyfits as pf
import ipdb
import sn_math as snm
import numpy as np
from configobj import ConfigObj
import sn_filehandling as flh
import sn_hardware as hardware
import flatmapfunctions as FM
from validate import Validator
import dm_functions as DM
import time


def define_control_region(image):
    """SHIFT- Click on the image to define the vertices of a polygon defining a region. May be convex or concave"""
    spots = pre.get_spot_locations(image, 
            comment='SHIFT-click to select the vertices region you want to control\n, then close the window')
    xs, ys = np.meshgrid( np.arange(image.shape[1]),
                            np.arange(image.shape[0]))
    pp = snm.points_in_poly(xs, ys, spots)
    return pp, spots 

if __name__ == "__main__":
    #configfilename = 'speckle_null_config.ini'
    #config = ConfigObj(configfilename)
    
    configfilename = 'speckle_null_config.ini'
    hardwareconfigfile = 'speckle_instruments.ini'
    configspecfile = 'speckle_null_config.spec'
    config = ConfigObj(configfilename, configspec=configspecfile)
    val = Validator()
    check = config.validate(val)
    
    regionfilename = config['CONTROLREGION']['filename']
    #pharo = hardware.fake_pharo()
    #Real thing
    pharo = hardware.PHARO_COM('PHARO', 
                configfile = hardwareconfigfile)
    #LOAD P3K HERE
    p3k = hardware.P3K_COM('P3K_COM', configfile = hardwareconfigfile)
    print("\n\nBeginning CONTROL REGION DEFINITION\n\n")
    time.sleep(1)

    print("\nComputing satellites")
    DMamp = 60 
    kvecr = 33
    additionmapx = DM.make_speckle_kxy(kvecr, 0,DMamp , 0) 
    additionmapy = DM.make_speckle_kxy(0,kvecr, DMamp, 0) 
    additionmap = additionmapx + additionmapy 
    
    print("saving initial flatmap")
    initial_flatmap = p3k.grab_current_flatmap()
    
    print ("sending new flatmap to p3k")
    status = p3k.load_new_flatmap(FM.convert_hodm_telem(initial_flatmap + additionmap))
    print("Retrieving bgd, flat, badpix")
    bgds = flh.setup_bgd_dict(config)
    
    firstim = pharo.take_src_return_imagedata(exptime = 4)
    image = pre.equalize_image(firstim, **bgds)
    image = firstim

    p , verts= define_control_region(image)
    verts = np.array(verts)
    config['CONTROLREGION']['verticesx'] = [x[0] for x in verts]
    config['CONTROLREGION']['verticesy'] = [y[1] for y in verts]
    flh.writeout(p, regionfilename)
    #config['CONTROLREGION']['filename'] = regionfilename
    config.write() 

    print "RELOADING INITIAL FLATMAP"
    status = p3k.load_new_flatmap(initial_flatmap)
    
    print "Configuration file written to "+config.filename    
    controlimage = p*image
    plt.imshow(controlimage)
    plt.xlim( (np.min(verts[:,0]), np.max(verts[:,0])))
    plt.ylim( (np.min(verts[:,1]), np.max(verts[:,1])))
    plt.title("This is your control region"+
              "\n saved as "+regionfilename)
    plt.show()
