%=========================================================
% p1640_cal.m
%
% p1640_cal('wavefront_1')
% 
% Loads wavefront error from p1640_cal
% Converts wavefront error to centroid offset update
% Coadds the update to the current centroid offsets
% Loads the new centroid offsets into HWFP
%
%========================================================

function []=p1640_cal(wavefront)

if nargin < 1
	help p1640_cal
	return
end

disp(' ');
disp('Starting p1640_cal on p3k-telem');

% establish time1 early, so we don't need PAUSE which hangs the shell script

[stat,dt]=unix('dbtime');
t1=dt(17:26);
t1=num2str(str2num(t1)-5);

% get hwfp status from p3k to extract the current centroid offsets
ao_cmd='ao hwfp';
err=system(ao_cmd);

cpath='/p3k/tables/p1640_cal/cent_offsets/';
wpath='/p3k/tables/p1640_cal/wavefront/';
ppath='/p3k/tables/cent_offsets/';

disp(['Loading ', wavefront]);
wave=load([wpath wavefront]);

% load the influence matrix
load('110712_infs');

[stat,dt]=unix('dbtime');
t2=dt(17:26);
t2=num2str(str2num(t2)+5);

db_cmd=sprintf('dbget hwfp_stat -start %s -stop %s -a -o /tmp/out',t1,t2);
err=system(db_cmd);
hwfp=readstat('/tmp/out.csv','hwfp_stat');

disp(['Grabbing current centroid offsets ',cell2mat(hwfp.cent_offs)]);
co_cur=load(cell2mat(hwfp.cent_offs));

disp('Calculating new centroid offsets');
co_update=infs * wave;

co_new=co_update' + co_cur;

filename=[cpath 'co_' t2];
disp(['New centroid offsets written to ', filename]);
save (filename, 'co_new', '-ascii')
save ([ppath 'co_p1640cal'], 'co_new', '-ascii')

disp(['Loading ',filename]);
hwfp_cmd = sprintf('ao hwfp cent_offsets=%s',[ppath 'co_p1640cal']);
err = system(hwfp_cmd);

disp('p1640_cal script is done');
disp(' ');

return
