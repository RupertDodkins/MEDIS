import sn_preprocessing as pre
import cv2
import os
import matplotlib.pyplot as plt
import pyfits as pf
import ipdb
import sn_math as snm
import numpy as np
from configobj import ConfigObj
import sn_filehandling as flh
import sn_hardware as hardware
import flatmapfunctions as FM
from validate import Validator
import flatmapfunctions as fmf
import dm_functions as DM
import time


def get_satellite_centroids(image, window=20):
    """centroid each satellite spot using a 2d gaussian"""
    spots = pre.get_spot_locations(image, eq=True,
            comment='SHIFT-Click on the satellites CLOCKWISE'+
                     'starting from 10 o clock,\n then close the window')
    #satellite centers
    scs = np.zeros((len(spots), 2))
    for idx,xy in enumerate(spots):
        subim = pre.subimage(image, xy, window=window)
        popt = snm.image_centroid_gaussian1(subim)
        xcenp = popt[1]
        ycenp = popt[2]
        xcen = xy[0]-round(window/2)+xcenp
        ycen = xy[1]-round(window/2)+ycenp
        scs[idx,:] = xcen, ycen
    return scs

def find_center(centers):
    """returns the mean of the centers"""
    return np.mean(centers, axis = 0)

def find_angle(centers):
    """uses the four centers, presumably square, to find the rotation angle of the DM"""
    center = np.mean(centers, axis = 0)
    reltocenter = centers-center
    angs = [np.arctan(reltocenter[i,1]/reltocenter[i,0])*180/np.pi for i in range(4)]
    for idx,ang in enumerate(angs):
        if ang<0:
            angs[idx]= ang+90.0

    assert np.std(angs)< 3.0
    angle = np.mean(angs)
    return angle

def get_lambdaoverd(centroids, cyclesperap):
    """Calcualtes lambda/d by taking the average 
    of the two diagonas of the square, then 
    divides by cycles per aperture (33 for a 66x66 dm, then divides by 2"""
    diag1dist = np.linalg.norm(centroids[0,:]
                              -centroids[2,:])
    diag2dist = np.linalg.norm(centroids[1,:]
                              -centroids[3,:])
    avgdiagdist = 0.5*(diag1dist+diag2dist)
    return avgdiagdist/2/cyclesperap


if __name__ == "__main__":
    #configfilename = 'speckle_null_config.ini'
    #config = ConfigObj(configfilename)
    configfilename = 'speckle_null_config.ini'
    hardwareconfigfile = 'speckle_instruments.ini'
    configspecfile = 'speckle_null_config.spec'
    config = ConfigObj(configfilename, configspec=configspecfile)
    val = Validator()
    check = config.validate(val)
    print "\n\n\n"
    print "This program performs DM registration"
    print "It takes a background image, then an image with satellites"
    print "It subtracts the two, asks you to click on the satellites and then figures out lambda/d, the center and rotation of the image"
    print "It then saves these values to the configuration file "+configfilename
    print "At the end, it reloads the initial flatmap, undoing the satellites"
    print "\n\n\n"
    
    pharo = hardware.PHARO_COM('PHARO', 
                configfile = hardwareconfigfile)
    p3k = hardware.P3K_COM('P3K_COM', configfile = hardwareconfigfile)
    #LOAD CURRENT FLATMAP 
    print("\n\nBeginning DM REGISTRATION\n\n")
    time.sleep(2)
    print("Retrieving bgd, flat, badpix")
    bgds = flh.setup_bgd_dict(config)
    
    
    use_centoffs = False

    if use_centoffs == False:
        initial_flatmap = p3k.grab_current_flatmap()
        p3k.safesend2('hwfp dm=off')
    if use_centoffs == True:
        initial_centoffs= p3k.grab_current_centoffs()
    
    #status = p3k.load_new_flatmap(FM.convert_hodm_telem(initial_flatmap))
    firstim = pharo.take_src_return_imagedata(exptime = 4)
    print("\nComputing satellites")
    DMamp = 30
    kvecr = 33
    additionmapx = DM.make_speckle_kxy(kvecr, 0,DMamp , 0) 
    additionmapy = DM.make_speckle_kxy(0,kvecr, DMamp, 0) 
    additionmap = additionmapx + additionmapy 
    print ("sending new flatmap to p3k")
    
    if use_centoffs == False:
        status = p3k.load_new_flatmap((initial_flatmap + additionmap))
    if use_centoffs == True:
        status = p3k.load_new_centoffs((initial_centoffs + 
                            fmf.convert_flatmap_centoffs(additionmap)))
    image = pharo.take_src_return_imagedata(exptime = 4) 

    image_res = image-firstim
    spotcenters = get_satellite_centroids(image_res)
    
    print spotcenters
    c =find_center(spotcenters)
    a =find_angle(spotcenters)
    
    config['IM_PARAMS']['centerx'] = c[0]
    config['IM_PARAMS']['centery'] = c[1]
    config['IM_PARAMS']['angle']  = a 
    
    #cyclesperap = int(config['AOSYS']['dmcyclesperap'])
    lambdaoverd = get_lambdaoverd(spotcenters, kvecr)
    config['IM_PARAMS']['lambdaoverd'] = lambdaoverd
   
    print "Image center: " , c
    print "DM angle: ", a
    print "lambda/D: ", str(lambdaoverd)
    config.write() 
    
    print "RELOADING INITIAL FLATMAP"
    if use_centoffs == False:
        status = p3k.load_new_flatmap(initial_flatmap)
    if use_centoffs == True:
        status = p3k.load_new_centoffs(initial_centoffs)
    
